import socket
import ssl

host_addr = '127.0.0.1'
host_port = 48081
server = (host_addr, host_port)


#DECOMMENT THIS LINES IF YOU WOULD USE A SELF-SIGNED CERTIFICATE
#context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH, cafile='ca.cert')
#server_sni_hostname = 'networksecuritydemacs'

#DECOMMENT THIS LINES IF YOU WOULD USE A LETSENCRYPT CERTIFICATE
#context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
#server_sni_hostname = 'networksecuritydemacs.cf'

context.verify_mode = ssl.CERT_REQUIRED
context.check_hostname = True
context.load_default_certs(ssl.Purpose.SERVER_AUTH)

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
ssl_sock = context.wrap_socket(s, server_hostname=server_sni_hostname)
ssl_sock.connect(server)
ssl_sock.do_handshake()

msg = input()

while msg != 'q':
    # send new message from input
    ssl_sock.send(msg.encode())
    print('Sent message!')
    print('waiting for response...')
    print(ssl_sock.recv(4096).decode())
    msg = input()

print('Closing connection, bye!')
ssl_sock.close()
