import socket
import ssl

listen_addr = '127.0.0.1'
listen_port = 48081
server = (listen_addr, listen_port)


context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)

#DECOMMENT THIS LINES IF YOU WOULD USE A SELF-SIGNED CERTIFICATE
server_cert = 'server.cert'
server_key = 'server.key'
context.load_cert_chain(certfile=server_cert, keyfile=server_key)

#DECOMMENT THIS LINES IF YOU WOULD USE A LETSENCRYPT CERTIFICATE
#server_key = 'privkey.pem'
#cert_chain = 'fullchain.pem'
#context.load_cert_chain(certfile=cert_chain, keyfile=server_key)

socket = socket.socket()
socket.bind(server)
socket.listen(5)

print("Waiting for client")
conn = context.wrap_socket(socket, server_side=True)
wrapped_socket, client_address = conn.accept()
print("Client connected: {}:{}".format(client_address[0], client_address[1]))

input_buffer = ''
while input_buffer != 'q':
    input_buffer = wrapped_socket.recv().decode()
    print(input_buffer)
    buf = input()
    wrapped_socket.send(buf.encode())
    print('Sent message')
    print('receiving message...')

print("Closing connection")
conn.shutdown(socket.SHUT_RDWR)
conn.close()
