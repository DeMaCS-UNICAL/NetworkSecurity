import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.ResultSet;
import java.sql.Statement;

public class Test {

	public static void main(String[] args) {

		try {

			/////////////////////////////////////////////////
			////////////// connection ///////////////////////
			/////////////////////////////////////////////////
			System.out.println("Try to connect to db ..");

			Driver driver = (Driver) Class.forName("com.mysql.jdbc.Driver")
					.newInstance();
			Connection connection = java.sql.DriverManager.getConnection(
					"jdbc:mysql://localhost/test", "root", "mysql");

			System.out.println("Connected to db ..");

			///////////////////////////////////////////////////
			////////////// statement //////////////////////////
			///////////////////////////////////////////////////
			Statement statement = connection.createStatement();

			///////////////////////////////////////////////////
			////////////// read input from user ///////////////
			// ////////////////////////////////////////////////
			String input = null;

			System.out.println("Insert input passphrase:");
			
			BufferedReader br = new BufferedReader(new InputStreamReader(
					System.in));

			input = br.readLine();

			///////////////////////////////////////////////////
			/////////// create/execute query string ///////////
			///////////////////////////////////////////////////


			String queryString = "SELECT * FROM impiegato where nome='" + input+ "';";

			System.out.println("Executing query .." + queryString);
				  
			ResultSet rs = statement.executeQuery(queryString);

			////////////////////////////////////////////////////
			////////////// display results //////////////////////
			/////////////////////////////////////////////////////
			
			System.out.println("Results ..");


			while (rs.next()) {
				System.out.print(rs.getString(1) + " " + rs.getString(2) + " "
						+ rs.getString(3) +" "+rs.getString(4) +" "+rs.getString(5) +"\n");

			}
			
			rs.close();
			statement.close();
			connection.close();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
