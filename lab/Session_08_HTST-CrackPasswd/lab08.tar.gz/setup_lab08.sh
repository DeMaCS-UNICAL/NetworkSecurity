#!/usr/bin/env bash
# Provisioning Lab 08 partendo dallo stato finale del Lab 07.
# Da eseguire come root sui nodi GNS3 indicati.
set -euo pipefail

ROLE="${1:?uso: setup_lab08.sh <bob|alice|darth>}"

case "$ROLE" in
  bob)
    wg-quick down wg0 2>/dev/null || true
    apt-get remove -y wireguard wireguard-tools 2>/dev/null || true
    apt-get update && apt-get install -y nginx-light openssl
    mkdir -p /etc/nginx/certs /var/www/bob
    openssl req -x509 -newkey rsa:2048 -nodes \
      -keyout /etc/nginx/certs/bob.key -out /etc/nginx/certs/bob.crt \
      -days 3650 -subj '/CN=bob.local'
    cp "$(dirname "$0")/nginx/login.html" /var/www/bob/
    cp "$(dirname "$0")/nginx/no-hsts.conf" /etc/nginx/sites-available/default
    systemctl restart nginx
    for spec in "u_top:123456" "u_word:sunshine" "u_leet:passw0rd!" \
                "u_rule:Sunshine2024!" "u_mask:Kxty99"; do
      u="${spec%%:*}"; p="${spec#*:}"
      id "$u" >/dev/null 2>&1 || useradd -m "$u"
      echo "$u:$p" | chpasswd
    done
    id alice >/dev/null 2>&1 || useradd -m alice
    echo 'alice:passw0rd!' | chpasswd
    systemctl enable --now ssh 2>/dev/null || true
    echo "Bob pronto. Profilo nginx attivo: no-hsts."
    ;;
  alice)
    wg-quick down wg0 2>/dev/null || true
    # Alice è Ubuntu headless: la vittima "naviga" con un browser testuale.
    apt-get update && apt-get install -y lynx
    grep -q 'bob.local' /etc/hosts || echo '10.0.0.20  bob.local' >> /etc/hosts
    if [ -f "$(dirname "$0")/bob.crt" ]; then
      cp "$(dirname "$0")/bob.crt" /usr/local/share/ca-certificates/bob.crt
      update-ca-certificates
    fi
    echo "Alice pronta. bob.local -> 10.0.0.20 in /etc/hosts."
    ;;
  darth)
    wg-quick down wg0 2>/dev/null || true
    # zlib1g-dev: header per compilare john jumbo (vedi sotto).
    apt-get update && apt-get install -y dsniff tcpdump hashcat \
      build-essential libssl-dev libgmp-dev libpcap-dev zlib1g-dev git \
      python3
    # MITM: si usa mitm/sslstrip_proxy.py (Python stdlib), NON mitmproxy.
    # Darth è i386 (32-bit) e mitmproxy non distribuisce binari standalone
    # a 32 bit; pip su questa distro datata è fragile. Il proxy custom
    # replica esattamente sslstrip_addon.py usando solo http.server/ssl/
    # urllib -> nessuna dipendenza, gira su qualunque Python 3.
    command -v python3 >/dev/null 2>&1 || {
      echo "python3 mancante su Darth: il proxy MITM non può girare" >&2
      exit 1
    }
    # ATTENZIONE: il pacchetto Debian/Ubuntu 'john' (1.9.0) NON supporta
    # sha512crypt ($6$). ES05 richiede john JUMBO, compilato da sorgente.
    if ! command -v john >/dev/null 2>&1 || \
       ! john --list=formats 2>/dev/null | grep -qi sha512crypt; then
      rm -rf /opt/john
      git clone --depth 1 https://github.com/openwall/john /opt/john
      ( cd /opt/john/src && ./configure && make -sj"$(nproc)" )
      for b in john unshadow; do
        printf '#!/bin/sh\nexec /opt/john/run/%s "$@"\n' "$b" \
          > "/usr/local/bin/$b"
        chmod +x "/usr/local/bin/$b"
      done
    fi
    # rockyou.txt per ES05b/c (preinstallato su Kali, da scaricare su Ubuntu)
    if [ ! -f /usr/share/wordlists/rockyou.txt ]; then
      mkdir -p /usr/share/wordlists
      if [ -f /usr/share/wordlists/rockyou.txt.gz ]; then
        gunzip -k /usr/share/wordlists/rockyou.txt.gz
      else
        curl -fsSL -o /usr/share/wordlists/rockyou.txt \
          https://github.com/brannondorsey/naive-hashcat/releases/download/data/rockyou.txt
      fi
    fi
    echo "Darth pronto. Tool MITM, john jumbo e rockyou.txt installati."
    ;;
  *) echo "ruolo sconosciuto: $ROLE" >&2; exit 1;;
esac
